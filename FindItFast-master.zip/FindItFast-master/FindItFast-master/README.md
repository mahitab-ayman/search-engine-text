# FindItFast
Searches input text files with Brute Force, the Knuth-Morris-Pratt Algorithm, and the Boyer Moore Algorithm, then outputs the results and time taken for each method.
