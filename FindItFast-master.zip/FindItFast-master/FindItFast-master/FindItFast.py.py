import time
import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import scrolledtext
from tkinter import ttk
from PIL import Image, ImageTk

# Brute Force Algorithm
def brute(userin, input): 
    y = 0  
    pos = [] 
    inputlength = input.length()
    userlength = userin.length()
    n, m, counter = 0, 0, 0

    while counter != inputlength:    
        DataIn1 = input.listdata(m)
        DataUser = userin.listdata(n)
        counter += 1

        if DataIn1 != DataUser:
            n = 0
            if DataIn1 == userin.listdata(n):
                n += 1
                m += 1
                if userlength == n:
                    y += 1
                    pos.append((counter - userlength + 1))
                    n = 0
            else:
                m += 1
        else:
            n += 1
            m += 1
            if userlength == n:
                y += 1
                pos.append((counter - userlength + 1))
                n = 0

    return pos, y

# KMP Algorithm
def kmp(seq, subseq):
    n = seq.length()
    m = subseq.length()
    pi = prefix(subseq)
    k = 0
    y = 0
    pos = []

    for i in range(n):
        while k > 0 and subseq.listdata(k) != seq.listdata(i):
            k = pi[k - 1]
        if subseq.listdata(k) == seq.listdata(i):
            k += 1
        if k == m:
            pos.append(i + 2 - m)
            y += 1
            k = pi[k - 1]

    return pos, y

def prefix(seq):
    m = seq.length()
    pi = [0] * m
    k = 0

    for i in range(1, m):
        while k > 0 and seq.listdata(k) != seq.listdata(i):
            k = pi[k - 1]
        if seq.listdata(k) == seq.listdata(i):
            k += 1
        pi[i] = k

    return pi

# Boyer Moore Algorithm    start from the end.
NO_OF_CHARS = 256

def badCharHeuristic(string, size):
    badChar = [-1] * NO_OF_CHARS
    for i in range(size):
        badChar[ord(string.listdata(i))] = i
    return badChar

def boyermoore(txt, pat):
    m = pat.length()
    n = txt.length()
    badChar = badCharHeuristic(pat, m)
    s = 0
    h = 0
    pos = []

    while s <= n - m:
        j = m - 1
        while j >= 0 and pat.listdata(j) == txt.listdata(s + j):
            j -= 1
        if j < 0:
            pos.append(s + 1)
            h += 1
            s += (m - badChar[ord(txt.listdata(s + m))] if s + m < n else 1)
        else:
            s += max(1, j - badChar[ord(txt.listdata(s + j))])

    return pos, h

# Performance Evaluation
def evaluate_performance(algorithm, *args):
    start = time.time()
    positions, count = algorithm(*args)
    end = time.time()
    duration = end - start
    return positions, count, duration

# Linked List
class Node:
    def __init__(self, dataval=None):
        self.dataval = dataval
        self.nextval = None

class SLinkedList:
    def __init__(self):
        self.headval = None

    def AtEnd(self, newdata):
        NewNode = Node(newdata)
        if self.headval is None:
            self.headval = NewNode
            return
        laste = self.headval
        while laste.nextval:
            laste = laste.nextval
        laste.nextval = NewNode

    def listdata(self, index):
        node = self.headval
        for _ in range(index):
            node = node.nextval
        return node.dataval

    def length(self):
        count = 0
        node = self.headval
        while node:
            count += 1
            node = node.nextval
        return count

# GUI Implementation
# GUI Implementation
# GUI Implementation
class TextSearchEngineGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Text Search Engine")
        
        # Set the style
        style = ttk.Style()
        style.configure("TButton",
                        foreground="black",
                        background="pink",
                        font=("Helvetica", 12, "bold"),
                        borderwidth="4")
        style.configure("TLabel",
                        foreground="black",
                        background="pink",
                        font=("Helvetica", 12),
                        borderwidth="4")
        style.configure("TEntry",
                        foreground="black",
                        background="pink",
                        font=("Helvetica", 12),
                        borderwidth="4")
        style.configure("TScrolledText",
                        foreground="black",
                        background="pink",
                        font=("Helvetica", 12),
                        borderwidth="4")

        self.canvas = tk.Canvas(root, width=800, height=600)
        self.canvas.pack(fill="both", expand=True)

        # Load and set background image
        self.bg_image = Image.open("C:\\Users\\mahya\\Downloads\\depositphotos_137623752-stock-photo-art-spring-background-fresh-flower.jpg")
        self.bg_image = self.bg_image.resize((800, 600), Image.LANCZOS)
        self.bg_photo = ImageTk.PhotoImage(self.bg_image)
        self.canvas.create_image(0, 0, image=self.bg_photo, anchor="nw")

        self.label = ttk.Label(root, text="Enter substring to search for:")
        self.canvas.create_window(400, 50, window=self.label)
        
        self.entry = ttk.Entry(root)
        self.canvas.create_window(400, 80, window=self.entry)
        
        self.file_button = ttk.Button(root, text="Select Text File", command=self.select_file)
        self.canvas.create_window(400, 120, window=self.file_button)
        
        self.search_button = ttk.Button(root, text="Search", command=self.search)
        self.canvas.create_window(400, 160, window=self.search_button)
        
        self.result_text = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=70, height=20)
        self.canvas.create_window(400, 350, window=self.result_text)
        
        self.file_path = None

    def select_file(self):
        self.file_path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if self.file_path:
            messagebox.showinfo("Selected File", f"File selected: {self.file_path}")
        else:
            messagebox.showwarning("No File", "No file selected")

    def search(self):
        substring = self.entry.get().lower()
        if not substring:
            messagebox.showwarning("Input Error", "Please enter a substring to search for")
            return
        if not self.file_path:
            messagebox.showwarning("File Error", "Please select a text file")
            return
        
        with open(self.file_path, "r") as file:
            text = file.read().lower()
        
        userList = SLinkedList()
        for char in substring:
            userList.AtEnd(char)
        
        textList = SLinkedList()
        for char in text:
            textList.AtEnd(char)
        
        self.result_text.delete(1.0, tk.END)
        
        # Brute Force Method
        pos, count, brutetime = evaluate_performance(brute, userList, textList)
        if count > 0:
            self.result_text.insert(tk.END, "\nBrute Force Method Initiated!\n")
            for position in pos:
                self.result_text.insert(tk.END, f"Found at: {position}\n")
            self.result_text.insert(tk.END, f"Found {count} Times!\n")
            self.result_text.insert(tk.END, f"\n{brutetime} seconds\n")

        # KMP Method
        pos, count, kmptime = evaluate_performance(kmp, textList, userList)
        if count > 0:
            self.result_text.insert(tk.END, "\nKMP Method Initiated\n")
            for position in pos:
                self.result_text.insert(tk.END, f"Found at: {position}\n")
            self.result_text.insert(tk.END, f"Found {count} Times!\n")
            self.result_text.insert(tk.END, f"\n{kmptime} seconds\n")

        # Boyer Moore Method
        pos, count, boyertime = evaluate_performance(boyermoore, textList, userList)
        if count > 0:
            self.result_text.insert(tk.END, "\nBoyer Moore Method Initiated\n")
            for position in pos:
                self.result_text.insert(tk.END, f"Found at: {position}\n")
            self.result_text.insert(tk.END, f"Found {count} Times!\n")
            self.result_text.insert(tk.END, f"\n{boyertime} seconds\n")
        
        # If no matches were found in any method
        if not pos:
            self.result_text.insert(tk.END, "Not found in the selected file\n")
        else:
            # Determine the fastest algorithm
            smallest_time = min(brutetime, kmptime, boyertime)
            if brutetime == kmptime == boyertime:
                self.result_text.insert(tk.END, f"The Fastest Speed is : {smallest_time} seconds\n")
                self.result_text.insert(tk.END, "All algorithms have the same speed\n")
            else:
                self.result_text.insert(tk.END, f"The Fastest Speed is : {smallest_time} seconds\n")
                if brutetime == smallest_time:
                    self.result_text.insert(tk.END, "Brute Force is the Fastest Algorithm\n")
                elif kmptime == smallest_time:
                    self.result_text.insert(tk.END, "KMP is the Fastest Algorithm\n")
                elif boyertime == smallest_time:
                    self.result_text.insert(tk.END, "Boyer Moore is the Fastest Algorithm\n")

def main():
    root = tk.Tk()
    app = TextSearchEngineGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
