def preprocess_bad_character_heuristic(pattern):
   
    bad_char = {}
    for i, char in enumerate(pattern):
        bad_char[char] = i
    return bad_char

def boyer_moore_search(text, pattern):
    
    n = len(text)
    m = len(pattern)
    bad_char = preprocess_bad_character_heuristic(pattern)

    occurrences = []
    i = 0
    while i <= n - m:
        j = m - 1
        while j >= 0 and pattern[j] == text[i + j]:
            j -= 1
        if j == -1:  # Complete match
            occurrences.append(i)
            i += m
        else:
            # Shift based on bad character heuristic
            shift = max(1, j - bad_char.get(text[i + j], -1))
            i += shift

    return occurrences

# Example usage
import matplotlib.pyplot as plt
import time

text = "this is a test string"
pattern = "test"

times = []
for n in range(1000):
    # Generate a dummy text of length n (you can replace this with your actual input data)
    dummy_text = "a" * n
    start_time = time.time()
    boyer_moore_search(dummy_text, pattern)
    execution = (time.time() - start_time) * (10**9)  # time in nanoseconds
    times.append(execution)

f, ax = plt.subplots()
ax.plot(range(1000), times, label='KMP search')
ax.set_xlabel('$n$ (Input size)')
ax.set_ylabel('Time in nanoseconds')
ax.set_title('moore string search execution time')
ax.legend(loc='best')
plt.show()
