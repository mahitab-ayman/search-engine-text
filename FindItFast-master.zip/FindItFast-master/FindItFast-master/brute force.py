def string_search(string, pattern):
    s_len = len(string)
    p_len = len(pattern)
    found = False
    i = 0
    for i in range(s_len - p_len + 1):
        j = 0
        for j in range(p_len):
            if string[i + j] != pattern[j]:
                break
        if j == p_len - 1:         # If we have reached the end of the pattern, we have found the pattern in the string
            found = True
            break
 
    if found:
        print("Found pattern at index ", i)
    else:
        print("Could not find pattern")
 
 
# Driver method
import matplotlib.pyplot as plt
import time

string = "this is a test string"
pattern = "test"

times = []
for n in range(1000):
    # Generate a dummy text of length n (you can replace this with your actual input data)
    dummy_text = "a" * n
    start_time = time.time()
    string_search(dummy_text, pattern)
    execution = (time.time() - start_time) * (10**9)  # time in nanoseconds
    times.append(execution)

f, ax = plt.subplots()
ax.plot(range(1000), times, label='KMP search')
ax.set_xlabel('$n$ (Input size)')
ax.set_ylabel('Time in nanoseconds')
ax.set_title('brute force string search execution time')
ax.legend(loc='best')
plt.show()