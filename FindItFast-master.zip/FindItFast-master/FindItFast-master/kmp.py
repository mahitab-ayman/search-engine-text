import matplotlib.pyplot as plt
import time

def compute_lps(pattern):
    """
    Compute the LPS (Longest Proper Prefix that is also a Suffix) array for the pattern.
    """
    m = len(pattern)
    lps = [0] * m
    length = 0  # Length of the previous longest prefix suffix

    i = 1
    while i < m:
        if pattern[i] == pattern[length]:
            length += 1
            lps[i] = length
            i += 1
        else:
            if length != 0:
                length = lps[length - 1]
            else:
                lps[i] = 0
                i += 1

    return lps

def kmp_search(text, pattern):
    """
    Search for occurrences of the pattern in the text using the KMP algorithm.
    Returns a list of starting indices where the pattern occurs.
    """
    n, m = len(text), len(pattern)
    lps = compute_lps(pattern)

    occurrences = []
    i, j = 0, 0
    while i < n:
        if pattern[j] == text[i]:
            i += 1
            j += 1

            if j == m:
                occurrences.append(i - j)
                j = lps[j - 1]
        else:
            if j != 0:
                j = lps[j - 1]
            else:
                i += 1

    return occurrences

# Example usage
text = "this is a test string"
pattern = "test"

times = []
for n in range(1000):
    # Generate a dummy text of length n (you can replace this with your actual input data)
    dummy_text = "a" * n
    start_time = time.time()
    kmp_search(dummy_text, pattern)
    execution = (time.time() - start_time) * (10**9)  # time in nanoseconds
    times.append(execution)

f, ax = plt.subplots()
ax.plot(range(1000), times, label='KMP search')
ax.set_xlabel('$n$ (Input size)')
ax.set_ylabel('Time in nanoseconds')
ax.set_title('KMP string search execution time')
ax.legend(loc='best')
plt.show()
